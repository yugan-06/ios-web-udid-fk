<?php
// 获取 User-Agent
$user_agent = $_SERVER['HTTP_USER_AGENT'];

// 定义允许访问的自带浏览器关键词 (iOS Safari 或 Android Chrome)
if (
    (strpos($user_agent, 'Safari') === false && strpos($user_agent, 'Mobile') === false) && // iOS Safari
    (strpos($user_agent, 'Chrome') === false && strpos($user_agent, 'Android') === false)  // Android Chrome
) {
    // 如果检测不到自带浏览器，显示错误信息
    echo "访问受限：请使用自带浏览器访问本页面。";
    exit;
}

// 之后是你的原始代码...
session_start();

// 获取传入的 UDID
$udid = isset($_GET['UDID']) ? $_GET['UDID'] : '';

// 如果没有传入 UDID，返回错误信息
if (empty($udid)) {
    echo json_encode(['success' => false, 'message' => '未提供UDID。']);
    exit();
}

// 定义存储文件路径
$laheiFile = 'lahei.txt';
$udidFile = 'udid.txt';

// 读取拉黑列表
$laheiList = file_exists($laheiFile) ? file($laheiFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

// 检查 UDID 是否被拉黑
if (in_array($udid, $laheiList)) {
    echo json_encode(['success' => false, 'message' => '此UDID已被拉黑。']);
    exit();
}

// 读取已记录的 UDID
$udids = file_exists($udidFile) ? file($udidFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

// 检查同一个 UDID 的记录次数
$udidCount = count(array_filter($udids, function($record) use ($udid) {
    return strpos($record, $udid) === 0;
}));

// 如果 UDID 的记录次数超过限制，返回错误信息
if ($udidCount >= 2) {
    echo json_encode(['success' => false, 'message' => '此UDID已超过获取次数限制。']);
    exit();
}

// 如果 UDID 检查通过，保存到 session 并返回成功信息
$_SESSION['udid'] = $udid;
echo json_encode(['success' => true, 'message' => 'UDID检测通过。']);
exit();
?>